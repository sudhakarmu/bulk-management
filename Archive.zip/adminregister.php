<?php

include('includes/header.php');
include('includes/navbar.php');

?>



<?php

include('includes/scripts.php');
include('includes/footer.php');

?>